package br.com.empresa.banco.cliente.intefaces;

public interface ValidaData {
	
	boolean dataIsValida(String data);
	
	boolean checkData(String data);
	
	String getDataFormatada();
	
}
