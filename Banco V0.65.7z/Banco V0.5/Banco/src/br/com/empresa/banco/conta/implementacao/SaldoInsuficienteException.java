package br.com.empresa.banco.conta.implementacao;

public class SaldoInsuficienteException extends RuntimeException{
	
	protected SaldoInsuficienteException(String mensagem){
		super(mensagem);
	}
	
	protected SaldoInsuficienteException(){
		super("O saldo da conta � menor que o valor desejado.");
	}

}
