package br.com.empresa.banco.cliente.intefaces;

public interface ValidaCPF {

	boolean cpfIsValido(String cpf);

	boolean checkCPF(String cpf);
	
	String formatCPF(String cpf, boolean mascara);
}
