package br.com.empresa.banco.cliente.implementacao;


import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import br.com.empresa.banco.cliente.intefaces.ValidaCPF;
import br.com.empresa.banco.cliente.intefaces.ValidaData;

public class Validacoes implements ValidaCPF, ValidaData{

	private String data;
	private DateTimeFormatter dataFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	private LocalDate dateTime;
	public boolean nomeIsValido(String nome){
		if(nome.length() <= 0){
			return false;
		}
		else{
			return true;
		}
	}
	
	@Override
	public boolean dataIsValida(String data) {
		if(data.length() <= 0)
			return false;
		else{
			if(this.checkData(data))
				return true;
		}
		return false;
	}
	
	@Override
	public boolean checkData(String data){
		/* ** Implementar novamente ** try{
			dateTime = LocalDate.parse(data, dataFormatter);
			return true;
		}
		catch(IllegalArgumentException | DateTimeParseException e1){
			System.out.println("Data inserida � inv�lida.");
		}
		catch(Exception e2){
			System.out.println("Houve um erro ao processar a data.");
			e2.printStackTrace();
		}*/
		return false;
	}
	
	
	@Override
	public boolean cpfIsValido(String cpf) {

		if(formatCPF(cpf, false).length() < 11 || formatCPF(cpf, false).length() > 11){
			return false;
		}
		else{
			if(checkCPF(cpf)) return true;
			else return false;
		}
	}

	@Override
	public boolean checkCPF(String cpf) {
		cpf = formatCPF(cpf, false);		
		try{
			String cpfSemDigitos = cpf.substring(0, cpf.length() - 2);
			cpfSemDigitos += validacao(cpfSemDigitos, 10);
			cpfSemDigitos += validacao(cpfSemDigitos, 11);
			if(cpf.equals(cpfSemDigitos)) return true;
		}
		
		catch(Exception e){
			System.out.println("Ocorreu um erro ao processar CPF.");
		}
		return false;
	}
	
	private String validacao(String cpf, int count) {
		int somatoria = 0;
		for(int i = 0; i < cpf.length(); i++){
			somatoria += Character.getNumericValue(cpf.charAt(i)) * count;
			count--;
		}
		String digito = Integer.toString(11 - (somatoria % 11));
		if(Integer.parseInt(digito) > 9) digito = "0";
		return digito;
	}

	@Override
	public String formatCPF(String cpf, boolean mascara) {
		if(!mascara) {
			cpf = cpf.replace(".", "");
			cpf = cpf.replace("-", "");
			return cpf;
		}
		else{
			int count = 1;
			String cpfFormatado = "";
			for(int i = 0; i < cpf.length(); i++){
				cpfFormatado += cpf.charAt(i);
				if(count == 3){
					cpfFormatado +=".";
					count = 1;
				}
				if(i == cpf.length() - 2){
					cpfFormatado += "-";
					break;
				}
				count++;
			}
		}
		return null;
	}

	@Override
	public String getDataFormatada() {
		if(dateTime.toString() != null || dateTime.toString() != "")
			return dateTime.toString();
		
		return null;
	}

}
