package br.com.empresa.banco.cliente.implementacao;

public class CpfInvalidoException extends Exception{
	
	protected CpfInvalidoException(){
		super("CPF inserido � inv�lido.");
	}
	
	protected CpfInvalidoException(String mensagem){
		super(mensagem);
	}

}
