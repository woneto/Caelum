package br.com.empresa.banco.conta.implementacao;
import java.util.Random;

public class GeradorNumeroConta {
	
	private static Random r = new Random();
	
	protected static int geraNumeroConta(){
		return r.nextInt(1000000);	
	}
}
