package br.com.empresa.banco.conta.implementacao;

import java.text.DecimalFormat;

import br.com.empresa.banco.conta.interfaces.Conta;

public class ContaPoupanca implements Conta, Comparable<ContaPoupanca> {

	private double saldo;
	private double limite;
	private int numeroConta;
	private String dataCriacaoConta;
	private DecimalFormat df = new DecimalFormat("0.00");
	
	
	public ContaPoupanca(){
		numeroConta = GeradorNumeroConta.geraNumeroConta();
	}
	
	@Override
	public double getSaldo() {
		return this.saldo + limite;
	}

	@Override
	public void depositar(double valor) {
		if(valor <= 0){
			throw new IllegalArgumentException("O valor inserido � inv�lido");
		}
		else{
			this.saldo += valor;
		}
	}

	@Override
	public void sacar(double valor) {
		if(this.saldo + this.limite < valor){
			throw new SaldoInsuficienteException("O valor desejado � maior que o saldo da conta.");
		}
		else{
			this.saldo -= valor;
		}
	}

	@Override
	public void informacoesConta() {
		System.out.println("N�mero da conta: " + this.getNumeroConta());
		System.out.println("Tipo de conta: Corrente");
		System.out.println("Data em que a conta foi criada: " + this.getDataCriacaoConta());
		System.out.println("Saldo dispon�vel: R$" + df.format(this.getSaldo()));
	}
	
	public boolean equals(Object objeto){
		if(!(objeto instanceof Conta)) return false;
		Conta outraConta = (Conta) objeto;
		if(this.saldo == outraConta.getSaldo()){
			return true;
		}
		return false;
	}
	
	@Override
	public int compareTo(ContaPoupanca outra) {
		return Integer.compare(this.getNumeroConta(), outra.getNumeroConta());
	}

	@Override
	public int getNumeroConta() {
		return this.numeroConta;
	}

	@Override
	public String getDataCriacaoConta() {
		return this.dataCriacaoConta;
	}

}
