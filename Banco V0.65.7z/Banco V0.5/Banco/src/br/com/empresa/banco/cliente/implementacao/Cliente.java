package br.com.empresa.banco.cliente.implementacao;

public class Cliente {

	private String nome;
	private String cpf;
	private String dataNascimento;
	
	private Validacoes validacao = new Validacoes();
	
	public Cliente(String nome, String cpf){
		
		if(!validacao.cpfIsValido(cpf) && !validacao.nomeIsValido(nome)){
			System.out.println("Valores inseridos s�o inv�lidos.");
		}
		else if(!validacao.cpfIsValido(cpf)){
			System.out.println("CPF inserido � inv�lido.");
		}
		else if(!validacao.nomeIsValido(nome)){
			System.out.println("Nome inserido � inv�lido.");
		}
	}
	
	public Cliente(String nome, String cpf, String dataNascimento){
		this(nome, cpf);
		if(validacao.dataIsValida(dataNascimento))
			this.dataNascimento = dataNascimento;
	}

	public void informacoesCliente(){
		if(this.nome != null && validacao.nomeIsValido(this.nome))
			System.out.println("Nome do cliente: " + this.nome);
		if(this.dataNascimento != null && validacao.dataIsValida(this.dataNascimento))
			System.out.println("Data de nascimento: " + this.dataNascimento);
		if(this.cpf != null && validacao.cpfIsValido(this.cpf))
			System.out.println("CPF: " + this.cpf);
	}
}
