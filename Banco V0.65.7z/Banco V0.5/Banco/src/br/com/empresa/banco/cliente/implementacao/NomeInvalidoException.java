package br.com.empresa.banco.cliente.implementacao;

public class NomeInvalidoException extends Exception {
	
	protected NomeInvalidoException(){
		super("Nome inserido � inv�lido.");
	}
	
	protected NomeInvalidoException(String mensagem){
		super(mensagem);
	}

}
