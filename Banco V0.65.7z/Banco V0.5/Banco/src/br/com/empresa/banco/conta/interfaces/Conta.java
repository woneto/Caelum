package br.com.empresa.banco.conta.interfaces;

public interface Conta {

	double getSaldo();
	
	void depositar(double valor);
	
	void sacar(double valor);
	
	void informacoesConta();
	
	boolean equals(Object objeto);
	
	int getNumeroConta();
	
	String getDataCriacaoConta();
}
