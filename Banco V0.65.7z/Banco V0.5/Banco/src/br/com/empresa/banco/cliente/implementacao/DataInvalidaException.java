package br.com.empresa.banco.cliente.implementacao;

public class DataInvalidaException extends Exception{

	protected DataInvalidaException() throws Exception{
		super("Data inserida � inv�lida.");
	}
	
	protected DataInvalidaException(String mensagem) throws Exception{
		super(mensagem);
	}
}
