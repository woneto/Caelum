package com.br.empresa.banco;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import br.com.empresa.banco.cliente.implementacao.Cliente;
import br.com.empresa.banco.conta.implementacao.ContaCorrente;
import br.com.empresa.banco.conta.interfaces.Conta;

class TestesConta{
	
}

class TestesContaCorrente{
	
	public void teste1(){
		
		Collection<Conta> contas = new HashSet<Conta>();
		Conta conta = new ContaCorrente();
		Conta conta1 = new ContaCorrente();
		Conta c2 = new ContaCorrente();
		Conta c3 = new ContaCorrente();
		contas.add(conta);
		contas.add(conta1);
		contas.add(c2);
		contas.add(c3);
		impressao(contas);
	}
	
	private void impressao(Collection<Conta> contas){
		Iterator<Conta> i = contas.iterator();
		
		while(i.hasNext()){
			System.out.println("N�mero da conta: " + i.next().getNumeroConta());
		}
	}
}

class TestesContaPoupanca{
	
}

class TestesTributaveis{
	
}

class TestesClientes{
	
	public void teste1(){
		System.out.println("Teste 1: ");
		Cliente cliente1 = new Cliente("Waldir", "430.051.308-27");
		cliente1.informacoesCliente();
		System.out.println();
		System.out.println();
	}
	
	public void teste2(){
		System.out.println("Teste 2: ");
		Cliente cliente2 = new Cliente("Waldir", "498.349.349-90", "15/07/1996");
		cliente2.informacoesCliente();
		System.out.println();
		System.out.println();
	}
	
	public void teste3(){
		System.out.println("Teste 3: ");
		Cliente cliente3 = new Cliente("Waldir", "");
		cliente3.informacoesCliente();
		System.out.println();
		System.out.println();
	}
	
	public void teste4(){
		System.out.println("Teste 4: ");
		Cliente cliente4 = new Cliente("", "");
		cliente4.informacoesCliente();
		System.out.println();
		System.out.println();
	}

	public void teste5() {
		System.out.println("Teste 5: ");
		Cliente cliente5 = new Cliente("WO", "", "15071996");
		cliente5.informacoesCliente();
		System.out.println();
		System.out.println();
	}
	
}
