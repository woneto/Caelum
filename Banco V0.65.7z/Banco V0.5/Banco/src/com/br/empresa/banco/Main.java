package com.br.empresa.banco;

public class Main{
	public static void main(String[] args){
		TestesClientes testesClientes = new TestesClientes();
		testesClientes.teste1();
		testesClientes.teste2();
		testesClientes.teste3();
		testesClientes.teste4();
		testesClientes.teste5();
		TestesContaCorrente testesContasCorrente = new TestesContaCorrente();
		testesContasCorrente.teste1();
	}
}